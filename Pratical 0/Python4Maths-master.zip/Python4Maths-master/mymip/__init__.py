from .mycplex import CPLEXversion,cplex,ptr,Env,ZeroOne,Integer,Continuous,SemiCont,SemiInt,Constraint,pSUM,sum,Model,__doc__
from .cpxconst import *
#__doc__ = .pycplex.__doc__
